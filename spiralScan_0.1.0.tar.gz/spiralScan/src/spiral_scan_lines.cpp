#include <Rcpp.h>
using namespace Rcpp;
using namespace std;



// [[Rcpp::plugins(cpp11)]]

double taylor_solve(double x) {
  return 2 * M_PI / pow(1 + pow(x, 2), 0.5);
}

double equation(double y, double x) {
  return pow(y, 2) + 2 * x * (x + y) * (1 - cos(y)) - 4 * pow(M_PI, 2);
}

//'@useDynLib CheckOverlap
//'@import Rcpp
//'@export
// [[Rcpp::export]]
DataFrame spiral_scan_lines(double beam_divergence_angle, double compensate_angle,
                            NumericMatrix FOU, Nullable<NumericVector> point = R_NilValue) {
  double R = max((FOU(1, 0) - FOU(0, 0)) / 2, (FOU(1, 1) - FOU(0, 1)) / 2);
  double x_, y_, r_;
  double r = beam_divergence_angle * 0.5;
  double current_theta = 0;
  double rho_current = 0;
  double step_length = beam_divergence_angle / pow(2, 0.5) - compensate_angle;

  NumericVector x, y;
  double xi(0), yi(0);
  if (point.isNotNull()) {
    NumericVector point_list = as<NumericVector>(point);
    x_ = point_list[0];
    y_ = point_list[1];
    r_ = point_list[2];
    if(pow(pow(x_ - xi, 2) + pow(y_ - yi, 2), 0.5) < r_ + r){
      DataFrame point_locus = DataFrame::create(
        _["x"] = 1,
        _["y"] = 1,
        _["r"] = 1
      );
      return point_locus;
    }
    while (pow(pow(x_ - xi, 2) + pow(y_ - yi, 2), 0.5) >= r_ + r) {
      double dt = taylor_solve(current_theta);
      current_theta += dt;
      rho_current = step_length * 0.5 / M_PI * current_theta;
      xi = rho_current * cos(current_theta);
      yi = rho_current * sin(current_theta);
      x.push_back(xi);
      y.push_back(yi);
    }
  }else{
    while (rho_current <= R) {
      double dt = taylor_solve(current_theta);
      current_theta += dt;
      rho_current = step_length * 0.5 / M_PI * current_theta;
      xi = rho_current * cos(current_theta);
      yi = rho_current * sin(current_theta);
      x.push_back(xi);
      y.push_back(yi);
    }
  }

  DataFrame point_locus = DataFrame::create(
    _["x"] = x,
    _["y"] = y,
    _["r"] = r
  );

  return point_locus;
}

